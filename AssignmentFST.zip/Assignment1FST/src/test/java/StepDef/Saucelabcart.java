package StepDef;


import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;


import cucumber.api.DataTable;
import cucumber.api.java.en.Given;


import testSetup.Testbase;

public class Saucelabcart extends Testbase{

	
	@Given("^user proceeds to checkout$")
	public void user_proceeds_to_checkout() throws Throwable {
		driver.findElement(By.xpath("//a[contains(@class,\"shopping\")]")).click();
		System.out.println("Shopping Cart icon clicked");

		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[contains(text(),\"Your Cart\")]")).isDisplayed();
		System.out.println("Cart Page displayed");
		
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[contains(text(),\"Checkout\")]")).isDisplayed();
		System.out.println("Checkoout Button available");
		driver.findElement(By.xpath("//button[contains(text(),\"Checkout\")]")).click();
		System.out.println("Checkoout Button clicked");
	}

	
	
}
