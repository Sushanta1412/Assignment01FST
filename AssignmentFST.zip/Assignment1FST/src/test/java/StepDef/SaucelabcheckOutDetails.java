package StepDef;


import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;


import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import testSetup.Testbase;

public class SaucelabcheckOutDetails extends Testbase{

	
	@Given("^user enters the following details for checkout$")
	public void user_enters_the_following_details_for_checkout(DataTable dataTable) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[contains(text(),\"Checkout\")]")).isDisplayed();
		System.out.println("Checkout Page displayed");
		
		Thread.sleep(1000);
		List<Map<String,String>> data=dataTable.asMaps(String.class, String.class);
		
		driver.findElement(By.name("firstName")).click();
		driver.findElement(By.xpath("//input[contains(@name,\"firstName\")]")).sendKeys(data.get(0).get("FirstName"));
		
		driver.findElement(By.name("lastName")).sendKeys(data.get(0).get("LastName"));
		driver.findElement(By.name("postalCode")).sendKeys(data.get(0).get("PostalCode"));
		
		System.out.println("Checkout Details entered");
	}

	@When("^user confirm checkout$")
	public void user_confirm_checkout() throws Throwable {
		driver.findElement(By.name("continue")).click();
	    
		System.out.println("Checkout confirmed");
	}

	@Then("^user verify final confirmation message$")
	public void user_verify_final_confirmation_message() throws Throwable {
	    driver.findElement(By.xpath("//span[contains(text(),\"Checkout\")]")).isDisplayed();
	    System.out.println("Order Details displayed.");
	    String totval=driver.findElement(By.xpath("//div[contains(@class,\"summary_total\")]")).getText();
	    System.out.println(totval);
	    
	    driver.findElement(By.xpath("//button[contains(text(),\"Finish\")]")).click();
	    System.out.println("Finish button clicked.");
	    
	    driver.findElement(By.xpath("//h2[contains(text(),\"THANK YOU FOR YOUR ORDER\")]")).isDisplayed();
	    System.out.println("Final Completion Message displayed");
	    
	    driver.findElement(By.xpath("//button[contains(text(),\"Back\")]")).click();
	}

	
	
}
