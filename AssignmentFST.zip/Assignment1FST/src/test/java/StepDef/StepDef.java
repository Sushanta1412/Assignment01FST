package StepDef;


import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class StepDef {

	WebDriver driver;
	
	@Given("^Lunch toolsQA$")
	public void lunch_toolsQA() throws Throwable {
		
		WebDriverManager.chromedriver().setup();
		driver= new ChromeDriver();

		driver.get("https://demoqa.com/automation-practice-form");

	}

	@When("^Tools QA page open$")
	public void tools_QA_page_open() throws Throwable {

		System.out.println(driver.findElement(By.id("firstName")).isDisplayed());
	}

	@Then("^Enter value in tools QA$")
	public void enter_value_in_tools_QA(DataTable dt) throws Throwable {

		Map<String,String> data = dt.asMap(String.class, String.class);
		
		driver.findElement(By.id("firstName")).sendKeys(data.get("FirstName"));
		driver.findElement(By.id("lastName")).sendKeys(data.get("LastName"));
		driver.findElement(By.id("userEmail")).sendKeys(data.get("Email"));
	}
	
	
	
	
}
