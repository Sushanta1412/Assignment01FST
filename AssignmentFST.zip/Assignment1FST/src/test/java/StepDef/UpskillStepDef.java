package StepDef;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;


public class UpskillStepDef {

	WebDriver driver;
	
	@Given("^Lunch Upskill$")
	public void lunch_Upskill() throws Throwable {
		WebDriverManager.chromedriver().setup();
		driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://elearningm1.upskills.in/index.php");
	}

	@When("^signUp button shown$")
	public void signup_button_shown() throws Throwable {
		System.out.println(driver.findElement(By.xpath("//a[contains(text(),'Sign up!')]")).isDisplayed());
	}

	@Then("^Click signUp$")
	public void click_signUp() throws Throwable {
		driver.findElement(By.xpath("//a[contains(text(),'Sign up!')]")).click();
	}

	@Then("^fill up the registeration Form for all mandatory fields$")
	public void fill_up_the_registeration_Form_for_all_mandatory_fields(DataTable dt) throws Throwable {
		
		Map<String,String> data = dt.asMap(String.class, String.class);
		
		String usernamevalue=data.get("Username");
		LocalDateTime currentDateTime = LocalDateTime.now();
	    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("ddMMyyhhmmss"); 
		String formattedDateTime = currentDateTime.format(dtf);
		usernamevalue=usernamevalue.concat(formattedDateTime);
		
		driver.findElement(By.name("firstname")).sendKeys(data.get("FirstName"));
		driver.findElement(By.name("lastname")).sendKeys(data.get("LastName"));
		driver.findElement(By.name("email")).sendKeys(data.get("Email"));			
		driver.findElement(By.name("username")).sendKeys(usernamevalue);
		driver.findElement(By.name("pass1")).sendKeys(data.get("Password"));
		driver.findElement(By.name("pass2")).sendKeys(data.get("Password"));
	}

	@Then("^Submit the details$")
	public void submit_the_details() throws Throwable {
		driver.findElement(By.xpath("//button[contains(text(),'Register')]")).click();
	}
	
	@When("^Verify Message \"([^\"]*)\"$")
	public void verify_Message(String stringval) throws Throwable {
		List<WebElement> confirmationtexts = driver.findElements(By.tagName("p"));
		System.out.println(confirmationtexts.size());
		for (WebElement webElement : confirmationtexts) {
		String texts = webElement.getText();
		if(texts.contains(stringval)) {
		System.out.println(stringval + ": Text Verified");
//		Assert.assertEquals(texts, stringval);
//		break;
		}
		}
		System.out.println("a");
	}
	


	@Then("^Click on Next$")
	public void click_on_Next() throws Throwable {
		driver.findElement(By.xpath("//button[contains(text(),'Next')]")).click();
	}

	@Then("^Click on Profile$")
	public void click_on_Profile() throws Throwable {
		
		driver.findElement(By.xpath("//a[contains(text(),'Homepage')]")).click();
		driver.findElement(By.xpath("//a[contains(@class,'dropdown-toggle')]")).click();
		driver.findElement(By.xpath("//ul[contains(@class,'dropdown-menu')]//a[contains(text(),'Profile')]")).click();

	}

	@Then("^Click on Compose Message$")
	public void click_on_Compose_Message() throws Throwable {
		
		driver.findElement(By.xpath("//li[@class='messages-icon ']//a")).click();
		
		driver.findElement(By.xpath("//img[@title='Compose message']/parent::a")).click();

	}

	@When("^Enter the details shown on the page$")
	public void enter_the_details_shown_on_the_page() throws Throwable {
		
		driver.findElement(By.xpath("//input[@name='title']")).sendKeys("value");

	}

	@Then("^Click on Send message$")
	public void click_on_Send_message() throws Throwable {
		
		driver.findElement(By.xpath("//button[text()=' Send message']")).click();

	}
	
	
	
	
}
